/*
 * delay_us.h
 *
 *  Created on: Oct 16, 2025
 *      Author: user9
 */

#ifndef INC_DELAY_US_H_
#define INC_DELAY_US_H_



#endif /* INC_DELAY_US_H_ */

//#include "main.h"

#include "stm32f4xx_hal.h"

#include "tim.h"

void delay_us(uint16_t us);
